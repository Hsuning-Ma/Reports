#!/bin/sh
#
# By Edward G.J. Lee <edt1023@speedymail.org>
# This code is Public Domain.
# You will need ttf2pt1/t1utils and ttfm(ttfinfo) to use this script.
#
# Changelog:
#
# 01-11-23 ���ͤ��l�ؿ��[�W�r���W�١A�H���ѧO�C
#          Use subdirectory.
# 02-06-10 �[�J���ͱ���r���]�w(�t�X fancyhdr package �һ�)�C
#          ���� (dvips & pdftex)map �ɡC
#          ���� dvipdfm-cjk �һݪ� cid.map ���e�C
#          �[�J�@�ǥ��n�����ը�ơC
#          slant-tfm, and create map files.
#          fix wrong path in check_tools().
# 02-06-12 fix (dvips)map(wrong subfonts' name).
#          use printf in create_type1(), comment from KhoGuan
#          <khoguan.bbs@bbs.sayya.org>
# 02-06-15 fix (dvios)map typo
#          use NUMLIST list instead number counter of for/whlie loops, thank
#          edwar <edwar.bbs@bbs.sayya.org>
#          merge create_tfm() to create_map()
# 02-06-18 use ttfinfo. add check_enc.
#          �۰ʧP�_�r���O�_�� Unicode font�A�æ۰ʧP�_ big5 �� gb �X�A�����P
#          �B�z�C�r���w������b�u�@�ؿ��U�A�i�H�B�z path�C
#          Oops, bug in create_map().
# 02-06-19 �W�[��� CJK �Ҧ��ϥΪ��r���W�١C����
#          goldencat <goldencat@ezdelivery.net>
# 03-06-21 fixed create_cidmap() to fit dvipdfmx(former dvipdfm-cjk).
#
# Functions:
# check_tools()    : check if ttf2pt1 package exist.
# check_ttf()      : check if file is TTF(C) and what the encoding is.
# check_enc()      : assign encoding, big5 and gb2312 only so far.
# create_type1()   : ttf2pt1
# create_tfm()     : merge to create_map(), we need not too many for loops.
# create_map()     : *.tfm for TeX and map files for dvips/pdftex
# create_cidmap()  : cid.map for dvipdfm-cjk.
# create_cjkfd()   : .fd file for CJK.
# create_pk()      : not yet.
# mkfont_help()    : not yet.
# select_func()    : not yet, may be will inside the main()
# use via ttfm     : not yet.
# choice_cjkname   : font name for CJK : not yet.
# install()        : 03-06-23
# write in C       : noooot yet, will include ttf2pt1/oto/showttf codes.
# GUI(gtk+)        : noooooooooooot yet.
#
# $Id: mkfont.sh,v 1.2 2003/11/17 18:53:43 edt1023 Exp $
#

FULLNAME=$1
FONTNAME=$2
FNAME=`basename $1`
eval `echo $FNAME | awk -F. '{printf "FHEAD=%s;FTAIL=%s",\$1,\$2}'`
TTF2PT1=`which ttf2pt1`
TTFINFO=`which ttfinfo`

check_tools()
{
  if [ ! -x "$TTF2PT1" ]
  then
    echo
    echo "You need ttf2pt1 to use this script."
    echo
    exit
  fi

  if [ ! -x "$TTFINFO" ]
  then
    echo
    echo "You need freetype-demos(ftdump) package to use this script."
    echo
    exit
  fi
}

check_ttf()
{
  if [ ! -f "$FULLNAME" ]
  then
    echo
    echo "File doesn't exist!"
    echo
    exit
  fi
    
  if [ "$FTAIL" != "ttf" ] && \
     [ "$FTAIL" != "TTF" ] && \
     [ "$FTAIL" != "ttc" ] && \
     [ "$FTAIL" != "TTC" ]
  then
    echo
    echo "File is not a TrueType font."
    echo
    exit
  fi

#  TEMP=`ftdump $FULLNAME | grep 'platform: 3, encoding: 1'`
#  if [ "$TEMP" != '   1: platform: 3, encoding: 1' ]
#  then
#    echo
#    echo "The script support Unicode Chinese TTF only so far."
#    echo
#    exit
#  fi
}

check_enc()
{
  if [ -d /usr/local/share/ttf2pt1/maps ]
  then
    MAPDIR=/usr/local/share/ttf2pt1/maps
    elif [ -d /usr/share/ttf2pt1/maps ]
    then
      MAPDIR=/usr/share/ttf2pt1/maps
  else
    echo
    echo "Where is your ttf2pt1 Chinese map files?"
    echo
    exit
  fi

  echo
  echo " Which Chinese TTF?"
  echo " 1. Big5  2. Gb2312"
  echo " choice 1 or 2."
  echo
  read CHOICE
  if [ "$CHOICE" = "1" ]
  then
    NUMLIST=`awk 'BEGIN{ n=1; while(n<56){printf "%02d\n",n; n++}}'`
    MAP=${MAPDIR}/cubig5.map
    PSENC1=Big5
    PSENC2=ETen-B5
    CJKENC=00
  else
    NUMLIST=`awk 'BEGIN{ n=1; while(n<36){printf "%02d\n",n; n++}}'`
    MAP=${MAPDIR}/cugb.map
    PSENC1=EUC
    PSENC2=GB-EUC
    CJKENC=10
  fi
}
create_type1()
{
  echo
  echo "Now create *.pfb and *.enc files, wait... "
  echo
  for i in $NUMLIST
  do
    ttf2pt1 -GE -pttf -Ohub -W0 -L $MAP+$i $FULLNAME ${FHEAD}$i
  done

# avoid dvips t1part module bugs.
  perl -pi -e 's/_/Z/g' *.t1a *.afm

  for ps in *.t1a
  do
    t1asm -b $ps > ${ps%.t1a}.pfb
  done
}

create_map()
{
MAPFILE=${FONTNAME}.map
ENCMAP=${FONTNAME}-enc.map
  echo
  echo "Create *.tfm and (dvips)map file, wait..."
  echo
  for i in $NUMLIST
  do
    PSNAME=`awk '/FontName/ {print $2}' ${FHEAD}$i.afm`
    afm2tfm ${FHEAD}$i.afm > /dev/null 2>&1
    afm2tfm ${FHEAD}$i.afm -s .167 ${FHEAD}s$i.tfm > /dev/null 2>&1
    cat >> $MAPFILE << EndOfFile
${FHEAD}$i $PSNAME <${FHEAD}$i.pfb
${FHEAD}s$i $PSNAME "0.167 SlantFont" <${FHEAD}$i.pfb
EndOfFile
    cat >> $ENCMAP << EndOfFile
${FHEAD}$i <${FHEAD}$i.enc <${FNAME}
EndOfFile
done
}

create_cidmap()
{
cat >> cid-x.map << EndOfFile
$FHEAD@$PSENC1@ ${PSENC2}-H :0:!$FNAME
${FHEAD}s@$PSENC1@ ${PSENC2}-H :0:!$FNAME -s .167
$FHEAD@$PSENC1@ ${PSENC2}-H :0:!$FNAME,Bold
${FHEAD}s@$PSENC1@ ${PSENC2}-H :0:!$FNAME,Bold -s .167
EndOfFile
}

create_cjkfd()
{
cat > c${CJKENC}${FONTNAME}.fd << EndOfFile
% This is c${CJKENC}${FONTNAME}.fd for CJK package.
% created by Edward G.J. Lee <edt1023@speedymail.org>
%
\ProvidesFile{c${CJKENC}${FONTNAME}.fd}[\filedate\space\fileversion]
\DeclareFontFamily{C${CJKENC}}{$FONTNAME}{\hyphenchar \font\m@ne}
\DeclareFontShape{C${CJKENC}}{$FONTNAME}{m}{n}{<-> CJK * $FHEAD}{}
\DeclareFontShape{C${CJKENC}}{$FONTNAME}{m}{sl}{<-> CJK * ${FHEAD}s}{}
\DeclareFontShape{C${CJKENC}}{$FONTNAME}{m}{it}{<-> CJKssub * $FONTNAME/m/sl}{}
\DeclareFontShape{C${CJKENC}}{$FONTNAME}{bx}{n}{<-> CJKb * $FHEAD}{\CJKbold}
\DeclareFontShape{C${CJKENC}}{$FONTNAME}{bx}{sl}{<-> CJKb * ${FHEAD}s}{\CJKbold}
\DeclareFontShape{C${CJKENC}}{$FONTNAME}{bx}{it}{<-> CJKssub * $FONTNAME/bx/sl}{\CJKbold}
\endinput
EndOfFile
}

# main() :)
if [ "$#" -ne 2 ]
then
  if [ "$#" -ne 1 ]
  then
    echo
    echo "Usage: `basename $0` your.ttf font_name"
    echo
    exit
  fi
FONTNAME=${FHEAD}
fi

check_tools
check_ttf
check_enc
create_type1
create_map
create_cidmap
create_cjkfd

AFM=${FONTNAME}-afm
TFM=${FONTNAME}-tfm
PFB=${FONTNAME}-pfb
ENC=${FONTNAME}-enc
rm -f *.t1a
mkdir -p $AFM $TFM $PFB $ENC
mv -f *.enc $ENC
mv -f *.afm $AFM
mv -f *.tfm $TFM
mv -f *.pfb $PFB
echo
echo "OK, all done. :-)"
echo
echo "${FONTNAME}.map is for dvips and Type1 Chinese fonts."
echo "${FONTNAME}-enc.map is for pdftex to embed Chinese TTF."
echo "cid-x.map is for dvipdfmx. Copy those files to the"
echo "proper \$TEXMF directories and do texhash(or mktexlsr)."
echo "Good luck.:)"
echo

